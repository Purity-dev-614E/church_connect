import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:group_management_church_app/core/auth/auth_wrapper.dart';
import 'package:group_management_church_app/core/constants/colors.dart';
import 'package:group_management_church_app/core/constants/text_styles.dart';
import 'package:group_management_church_app/data/models/region_model.dart';
import 'package:group_management_church_app/data/models/user_model.dart';
import 'package:group_management_church_app/data/providers/auth_provider.dart';
import 'package:group_management_church_app/data/providers/region_provider.dart';
import 'package:group_management_church_app/data/providers/user_provider.dart';
import 'package:group_management_church_app/widgets/custom_button.dart';
import 'package:group_management_church_app/widgets/input_field.dart';
import 'package:provider/provider.dart';
import 'package:group_management_church_app/widgets/custom_notification.dart';

class ProfileSetupScreen extends StatefulWidget {
  final String userId;
  final String email;
  
  const ProfileSetupScreen({
    Key? key,
    required this.userId,
    required this.email,
  }) : super(key: key);

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _isLoadingRegions = false;
  
  // Form controllers
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _contactController = TextEditingController();
  final TextEditingController _nextOfKinController = TextEditingController();
  final TextEditingController _nextOfKinContactController = TextEditingController();
  
  // Selected gender
  String _selectedGender = 'male';
  final List<String> _genderOptions = ['male', 'female'];
  
  // Selected region
  String? _selectedRegionId;
  List<RegionModel> _regions = [];
  
  // Default role is 'user' - only super_admin can change roles
  final String _userRole = 'user';

  @override
  void initState() {
    super.initState();
    // We need to use a post-frame callback because ModalRoute.of(context) is not available in initState
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadUserData();
      _loadRegions();
    });
  }
  
  // Load available regions
  Future<void> _loadRegions() async {
    setState(() {
      _isLoadingRegions = true;
    });
    
    try {
      final regionProvider = Provider.of<RegionProvider>(context, listen: false);
      await regionProvider.loadRegions();
      
      setState(() {
        _regions = regionProvider.regions;
        _isLoadingRegions = false;
      });
    } catch (e) {
      _showError('Error loading regions: $e');
      setState(() {
        _isLoadingRegions = false;
      });
    }
  }
  
  void _showError(String message) {
    CustomNotification.show(
      context: context,
      message: message,
      type: NotificationType.error,
    );
  }

  void _showSuccess(String message) {
    CustomNotification.show(
      context: context,
      message: message,
      type: NotificationType.success,
    );
  }

  void _showInfo(String message) {
    CustomNotification.show(
      context: context,
      message: message,
      type: NotificationType.info,
    );
  }
  
  Future<void> _loadUserData() async {
    // Check if we're in edit mode
    final isEditMode = ModalRoute.of(context)?.settings.arguments == 'edit_mode';
    
    if (isEditMode) {
      setState(() {
        _isLoading = true;
      });
      
      try {
        // Load current user data to pre-fill the form
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        await userProvider.loadUser(widget.userId);
        final currentUser = userProvider.currentUser;
        
        if (currentUser != null) {
          // Pre-fill form fields with current user data
          setState(() {
            _fullNameController.text = currentUser.fullName;
            _contactController.text = currentUser.contact;
            _nextOfKinController.text = currentUser.nextOfKin;
            _nextOfKinContactController.text = currentUser.nextOfKinContact;
            
            // Set gender if it's one of the available options
            if (_genderOptions.contains(currentUser.gender)) {
              _selectedGender = currentUser.gender;
            }
            
            // Set region if available
            if (currentUser.regionId != null) {
              _selectedRegionId = currentUser.regionId;
            }
          });
        }
      } catch (e) {
        _showError('Error loading user data: $e');
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _contactController.dispose();
    _nextOfKinController.dispose();
    _nextOfKinContactController.dispose();
    super.dispose();
  }

  // Validate phone number format
  String? _validatePhoneNumber(String? value) {
    if (value == null || value.isEmpty) {
      return 'Phone number is required';
    }
    
    // Simple validation for phone number format
    final phoneRegExp = RegExp(r'^\+?[0-9]{10,15}$');
    if (!phoneRegExp.hasMatch(value)) {
      return 'Enter a valid phone number';
    }
    
    return null;
  }

  // Validate full name
  String? _validateFullName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Full name is required';
    }
    
    if (value.length < 3) {
      return 'Name must be at least 3 characters';
    }
    
    return null;
  }

  // Submit form
  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      // Validate region selection
      if (_selectedRegionId == null || _selectedRegionId!.isEmpty) {
        _showError('Please select your region');
        return;
      }
      
      setState(() {
        _isLoading = true;
      });
      
      try {
        // Get the current user to preserve the role
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        final authProvider = Provider.of<AuthProvider>(context, listen: false);
        
        // Try to get the current user to preserve their role
        await userProvider.loadUser(widget.userId);
        final currentUser = userProvider.currentUser;
        
        // Use existing role if available, otherwise default to 'user'
        final role = currentUser?.role ?? _userRole;
        
        // Get selected region name for success message
        String selectedRegionName = 'your region';
        if (_selectedRegionId != null) {
          final selectedRegion = _regions.firstWhere(
            (region) => region.id == _selectedRegionId,
            orElse: () => RegionModel(id: '', name: ''),
          );
          if (selectedRegion.name.isNotEmpty) {
            selectedRegionName = selectedRegion.name;
          }
        }
        
        // Create user model with updated information
        final userModel = UserModel(
          id: widget.userId,
          fullName: _fullNameController.text.trim(),
          email: widget.email,
          contact: _contactController.text.trim(),
          nextOfKin: _nextOfKinController.text.trim(),
          nextOfKinContact: _nextOfKinContactController.text.trim(),
          role: role, // Preserve existing role
          gender: _selectedGender,
          regionId: _selectedRegionId,
          regionName: selectedRegionName != 'your region' ? selectedRegionName : null,
        );
        
        // Update user profile
        final success = await authProvider.updateProfile(userModel);
        
        if (success) {
          // Update user in UserProvider
          await userProvider.loadUser(widget.userId);
          
          // Show success message with region information
          _showSuccess('Profile updated successfully! You are now part of $selectedRegionName region.');
          
          // Check if we're coming from ProfileScreen (edit mode)
          final isEditMode = ModalRoute.of(context)?.settings.arguments == 'edit_mode';
          
          if (isEditMode) {
            // Return to ProfileScreen with success result
            if (mounted) {
              Navigator.of(context).pop(true);
            }
          } else {
            // First-time setup - navigate to AuthWrapper
            if (mounted) {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => const AuthWrapper()),
              );
            }
          }
        } else {
          if (mounted) {
            _showError('Failed to update profile. Please try again.');
          }
        }
      } catch (e) {
        // Show error message
        if (mounted) {
          _showError('Error: ${e.toString()}');
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  
                  // Header
                  Text(
                    ModalRoute.of(context)?.settings.arguments == 'edit_mode'
                      ? 'Edit Your Profile'
                      : 'Complete Your Profile',
                    style: TextStyles.heading1.copyWith(
                      color: AppColors.primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  
                  Text(
                    ModalRoute.of(context)?.settings.arguments == 'edit_mode'
                      ? 'Update your personal information below.'
                      : 'Please provide your personal information to complete your account setup.',
                    style: TextStyles.bodyText,
                  ),
                  const SizedBox(height: 32),
                  
                  // Profile picture section
                  _buildProfilePictureSection(),
                  const SizedBox(height: 32),
                  
                  // Personal information section
                  _buildPersonalInfoSection(),
                  const SizedBox(height: 32),
                  
                  // Emergency contact section
                  _buildEmergencyContactSection(),
                  const SizedBox(height: 32),
                  
                  // Additional information section
                  _buildAdditionalInfoSection(),
                  const SizedBox(height: 40),
                  
                  // Submit button
                  CustomButton(
                    label: ModalRoute.of(context)?.settings.arguments == 'edit_mode'
                      ? 'Save Changes'
                      : 'Complete Setup',
                    onPressed: _submitForm,
                    isLoading: _isLoading,
                    color: AppColors.primaryColor,
                    icon: ModalRoute.of(context)?.settings.arguments == 'edit_mode'
                      ? Icons.save
                      : Icons.check_circle,
                    isPulsing: true,
                    pulseEffect: PulseEffectType.glow,
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfilePictureSection() {
    return Center(
      child: Column(
        children: [
          Stack(
            children: [
              // Profile picture container
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.primaryColor,
                    width: 2,
                  ),
                ),
                child: const Center(
                  child: Icon(
                    Icons.person,
                    size: 60,
                    color: AppColors.primaryColor,
                  ),
                ),
              ),
              
              // Edit button
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white,
                      width: 2,
                    ),
                  ),
                  child: IconButton(
                    icon: const Icon(
                      Icons.camera_alt,
                      size: 20,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      // TODO: Implement image picker
                      _showInfo('Profile picture upload will be implemented');
                    },
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            'Add Profile Picture',
            style: TextStyles.bodyText.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalInfoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('Personal Information', Icons.person),
        const SizedBox(height: 16),
        
        // Full Name
        EnhancedInputField(
          controller: _fullNameController,
          label: 'Full Name',
          hintText: 'Enter your full name',
          prefixIcon: Icons.person_outline,
          validator: _validateFullName,
          autovalidate: true,
        ),
        const SizedBox(height: 16),
        
        // Email (non-editable, from login)
        EnhancedInputField(
          controller: TextEditingController(text: widget.email),
          label: 'Email Address',
          prefixIcon: Icons.email_outlined,
          enabled: false,
          filled: true,
          fillColor: Colors.grey[200],
        ),
        const SizedBox(height: 16),
        
        // Phone Number
        EnhancedInputField(
          controller: _contactController,
          label: 'Phone Number',
          hintText: 'Enter your phone number',
          prefixIcon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          validator: _validatePhoneNumber,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(15),
          ],
          autovalidate: true,
        ),
        const SizedBox(height: 16),
        
        // Gender Selection
        _buildDropdownField(
          label: 'Gender',
          icon: Icons.wc,
          value: _selectedGender,
          items: _genderOptions,
          onChanged: (value) {
            if (value != null) {
              setState(() {
                _selectedGender = value;
              });
            }
          },
        ),
      ],
    );
  }

  Widget _buildEmergencyContactSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('Emergency Contact', Icons.contact_phone),
        const SizedBox(height: 16),
        
        // Next of Kin
        EnhancedInputField(
          controller: _nextOfKinController,
          label: 'Next of Kin',
          hintText: 'Enter name of next of kin',
          prefixIcon: Icons.person_outline,
          validator: _validateFullName,
        ),
        const SizedBox(height: 16),
        
        // Next of Kin Contact
        EnhancedInputField(
          controller: _nextOfKinContactController,
          label: 'Next of Kin Phone Number',
          hintText: 'Enter next of kin phone number',
          prefixIcon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          validator: _validatePhoneNumber,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(15),
          ],
        ),
      ],
    );
  }

  Widget _buildAdditionalInfoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('Additional Information', Icons.info_outline),
        const SizedBox(height: 16),
        
        // Region selection dropdown
        _buildRegionDropdown(),
        const SizedBox(height: 16),
        
        // Display role information (not editable)
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.primaryColor.withOpacity(0.5)),
            borderRadius: BorderRadius.circular(8),
            color: Colors.grey[200],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              Icon(
                Icons.work_outline,
                color: AppColors.primaryColor,
                size: 24,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Role in Church',
                      style: TextStyles.bodyText.copyWith(
                        color: AppColors.textColor.withOpacity(0.7),
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'User',
                      style: TextStyles.bodyText.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Note: Only Super Admins can change user roles',
                      style: TextStyles.bodyText.copyWith(
                        fontSize: 12,
                        color: AppColors.textColor.withOpacity(0.6),
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildRegionDropdown() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.primaryColor.withOpacity(0.7)),
        borderRadius: BorderRadius.circular(12),
        color: AppColors.primaryColor.withOpacity(0.05),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.location_on,
                  color: AppColors.primaryColor,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Text(
                              'Your Region',
                              style: TextStyles.bodyText.copyWith(
                                color: AppColors.textColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Icon(
                              Icons.star,
                              color: AppColors.secondaryColor,
                              size: 16,
                            ),
                          ],
                        ),
                        // View all regions button
                        TextButton(
                          onPressed: () => _showAllRegions(),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'View All',
                                style: TextStyles.bodyText.copyWith(
                                  color: AppColors.primaryColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(width: 2),
                              const Icon(
                                Icons.info_outline,
                                color: AppColors.primaryColor,
                                size: 14,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Select the region you belong to for group assignments',
                      style: TextStyles.bodyText.copyWith(
                        fontSize: 12,
                        color: AppColors.textColor.withOpacity(0.7),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (_isLoadingRegions)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 8.0),
                        child: Center(
                          child: SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          ),
                        ),
                      )
                    else if (_regions.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.errorColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.errorColor.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.error_outline,
                              color: AppColors.errorColor,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'No regions available. Please contact an administrator.',
                                style: TextStyles.bodyText.copyWith(
                                  color: AppColors.errorColor,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.primaryColor.withOpacity(0.3)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _selectedRegionId,
                            isExpanded: true,
                            hint: Text(
                              'Select your region',
                              style: TextStyles.bodyText.copyWith(
                                color: AppColors.textColor.withOpacity(0.5),
                              ),
                            ),
                            icon: const Icon(Icons.arrow_drop_down, color: AppColors.primaryColor),
                            style: TextStyles.bodyText.copyWith(
                              fontWeight: FontWeight.w500,
                            ),
                            onChanged: (String? newValue) {
                              setState(() {
                                _selectedRegionId = newValue;
                              });
                              
                              // Show region info if available
                              if (newValue != null) {
                                final selectedRegion = _regions.firstWhere(
                                  (region) => region.id == newValue,
                                  orElse: () => RegionModel(id: '', name: ''),
                                );
                                
                                if (selectedRegion.name.isNotEmpty) {
                                  _showRegionInfo(selectedRegion);
                                }
                              }
                            },
                            items: _regions.map<DropdownMenuItem<String>>((RegionModel region) {
                              return DropdownMenuItem<String>(
                                value: region.id,
                                child: Text(region.name),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          if (!_isLoadingRegions && _regions.isNotEmpty && _selectedRegionId == null)
            Container(
              margin: const EdgeInsets.only(top: 12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.secondaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.secondaryColor.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline,
                    color: AppColors.secondaryColor,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Please select your region to continue',
                      style: TextStyles.bodyText.copyWith(
                        fontSize: 12,
                        color: AppColors.secondaryColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
  
  // Show region information dialog
  void _showRegionInfo(RegionModel region) {
    // Only show dialog if there's a description
    if (region.description == null || region.description!.isEmpty) {
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.location_on,
              color: AppColors.primaryColor,
              size: 24,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                region.name,
                style: TextStyles.heading2.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Region Information',
              style: TextStyles.bodyText.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.secondaryColor,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              region.description ?? 'No description available',
              style: TextStyles.bodyText,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
  
  // Show all available regions in a dialog
  void _showAllRegions() {
    if (_regions.isEmpty) {
      _showInfo('No regions available');
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.map,
              color: AppColors.primaryColor,
              size: 24,
            ),
            const SizedBox(width: 8),
            Text(
              'Available Regions',
              style: TextStyles.heading2.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Container(
          width: double.maxFinite,
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.5,
          ),
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: _regions.length,
            itemBuilder: (context, index) {
              final region = _regions[index];
              final isSelected = _selectedRegionId == region.id;
              
              return Card(
                elevation: isSelected ? 2 : 0,
                color: isSelected 
                  ? AppColors.primaryColor.withOpacity(0.1) 
                  : Colors.white,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(
                    color: isSelected 
                      ? AppColors.primaryColor 
                      : Colors.grey.withOpacity(0.3),
                    width: isSelected ? 2 : 1,
                  ),
                ),
                child: InkWell(
                  onTap: () {
                    setState(() {
                      _selectedRegionId = region.id;
                    });
                    Navigator.of(context).pop();
                  },
                  borderRadius: BorderRadius.circular(8),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.location_on,
                              color: isSelected 
                                ? AppColors.primaryColor 
                                : AppColors.secondaryColor,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                region.name,
                                style: TextStyles.bodyText.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: isSelected 
                                    ? AppColors.primaryColor 
                                    : AppColors.textColor,
                                ),
                              ),
                            ),
                            if (isSelected)
                              Container(
                                padding: const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: AppColors.primaryColor,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.check,
                                  color: Colors.white,
                                  size: 16,
                                ),
                              ),
                          ],
                        ),
                        if (region.description != null && region.description!.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            region.description!,
                            style: TextStyles.bodyText.copyWith(
                              fontSize: 14,
                              color: AppColors.textColor.withOpacity(0.7),
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          color: AppColors.primaryColor,
          size: 24,
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyles.heading2.copyWith(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ],
    );
  }

  Widget _buildDropdownField({
    required String label,
    required IconData icon,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.primaryColor.withOpacity(0.5)),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Icon(
            icon,
            color: AppColors.primaryColor,
            size: 24,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                isExpanded: true,
                icon: const Icon(Icons.arrow_drop_down, color: AppColors.primaryColor),
                style: TextStyles.bodyText,
                onChanged: onChanged,
                items: items.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

