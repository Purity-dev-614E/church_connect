import 'package:flutter/foundation.dart';

import '../../services/analytics_services/super_admin_analytics_service.dart';

// Parameter classes
class MemberParticipationParams {
  final String? startDate;
  final String? endDate;

  MemberParticipationParams({this.startDate, this.endDate});

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is MemberParticipationParams &&
        other.startDate == startDate &&
        other.endDate == endDate;
  }

  @override
  int get hashCode => startDate.hashCode ^ endDate.hashCode;
}

class SuperAdminAnalyticsProvider extends ChangeNotifier {
  final SuperAdminAnalyticsService _analyticsService;
  
  // State variables
  bool _isLoading = false;
  String? _errorMessage;
  
  // Group analytics data
  Map<String, Map<String, dynamic>> _groupDemographics = {};
  Map<String, Map<String, dynamic>> _groupAttendanceStats = {};
  Map<String, Map<String, dynamic>> _groupGrowthAnalytics = {};
  Map<String, Map<String, dynamic>> _compareGroupsData = {};
  
  // Attendance analytics data
  Map<String, Map<String, dynamic>> _attendanceByPeriod = {};
  Map<String, Map<String, dynamic>> _overallAttendanceByPeriod = {};
  Map<String, Map<String, dynamic>> _userAttendanceTrends = {};
  
  // Event analytics data
  Map<String, Map<String, dynamic>> _eventParticipationStats = {};
  Map<String, Map<String, dynamic>> _compareEventAttendance = {};
  
  // Member analytics data
  Map<String, dynamic> _memberParticipationStats = {};
  Map<String, dynamic> _memberActivityStatus = {};
  
  // Dashboard data
  Map<String, dynamic> _dashboardSummary = {};
  Map<String, Map<String, dynamic>> _groupDashboardData = {};
  Map<String, dynamic> _combinedDashboard = {};
  
  // Additional data for super admin
  Map<String, dynamic> _attendanceTrends = {};
  Map<String, dynamic> _groupGrowthTrends = {};
  List<dynamic> _recentGroups = [];
  List<dynamic> _recentUsers = [];
  
  // Getters
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  Map<String, dynamic> get dashboardSummary => _dashboardSummary;
  Map<String, dynamic> get memberActivityStatus => _memberActivityStatus;
  Map<String, dynamic> get attendanceTrends => _attendanceTrends;
  Map<String, dynamic> get groupGrowthTrends => _groupGrowthTrends;
  List<dynamic> get recentGroups => _recentGroups;
  List<dynamic> get recentUsers => _recentUsers;
  
  SuperAdminAnalyticsProvider({String baseUrl = 'YOUR_API_BASE_URL', String token = 'YOUR_AUTH_TOKEN'}) 
      : _analyticsService = SuperAdminAnalyticsService(
          baseUrl: baseUrl,
          token: token,
        );
  
  // Helper methods
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void _handleError(String operation, dynamic error) {
    _errorMessage = 'Error $operation: $error';
    debugPrint(_errorMessage);
    notifyListeners();
  }
  
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
  
  // Group Analytics Methods
  Future<Map<String, dynamic>> getGroupDemographics(String groupId) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getGroupDemographics(groupId);
      _groupDemographics[groupId] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching group demographics', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> getGroupAttendanceStats(String groupId) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getGroupAttendanceStats(groupId);
      _groupAttendanceStats[groupId] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching group attendance stats', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> getGroupGrowthAnalytics(String groupId) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getGroupGrowthAnalytics(groupId);
      _groupGrowthAnalytics[groupId] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching group growth analytics', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> compareGroups(List<String> groupIds) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.compareGroups(groupIds);
      final key = groupIds.join('-');
      _compareGroupsData[key] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('comparing groups', error);
      _setLoading(false);
      return {};
    }
  }
  
  // Attendance Analytics Methods
  Future<Map<String, dynamic>> getAttendanceByPeriod(String period) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getAttendanceByPeriod(period);
      _attendanceByPeriod[period] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching attendance by period', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> getOverallAttendanceByPeriod(String period) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getOverallAttendanceByPeriod(period);
      _overallAttendanceByPeriod[period] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching overall attendance by period', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> getUserAttendanceTrends(String userId) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getUserAttendanceTrends(userId);
      _userAttendanceTrends[userId] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching user attendance trends', error);
      _setLoading(false);
      return {};
    }
  }
  
  // Event Analytics Methods
  Future<Map<String, dynamic>> getEventParticipationStats(String eventId) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getEventParticipationStats(eventId);
      _eventParticipationStats[eventId] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching event participation stats', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> compareEventAttendance(List<String> eventIds) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.compareEventAttendance(eventIds);
      final key = eventIds.join('-');
      _compareEventAttendance[key] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('comparing event attendance', error);
      _setLoading(false);
      return {};
    }
  }
  
  // Member Analytics Methods
  Future<Map<String, dynamic>> getMemberParticipationStats({
    String? startDate,
    String? endDate,
  }) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getMemberParticipationStats(
        startDate: startDate,
        endDate: endDate,
      );
      _memberParticipationStats = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching member participation stats', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> getMemberActivityStatus() async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getMemberActivityStatus();
      _memberActivityStatus = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching member activity status', error);
      _setLoading(false);
      return {};
    }
  }
  
  // Dashboard Analytics Methods
  Future<Map<String, dynamic>> getDashboardSummary() async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getDashboardSummary();
      _dashboardSummary = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching dashboard summary', error);
      _setLoading(false);
      return {};
    }
  }
  
  Future<Map<String, dynamic>> getGroupDashboardData(String groupId) async {
    _setLoading(true);
    try {
      final data = await _analyticsService.getGroupDashboardData(groupId);
      _groupDashboardData[groupId] = data;
      _errorMessage = null;
      _setLoading(false);
      return data;
    } catch (error) {
      _handleError('fetching group dashboard data', error);
      _setLoading(false);
      return {};
    }
  }
  
  // Combined Dashboard Data
  Future<Map<String, dynamic>> getCombinedDashboard() async {
    _setLoading(true);
    try {
      // Get dashboard summary
      final summary = await getDashboardSummary();
      
      // Combine the data
      final combinedData = {
        'summary': summary,
        'timestamp': DateTime.now().toIso8601String(),
      };
      
      _combinedDashboard = combinedData;
      _errorMessage = null;
      _setLoading(false);
      return combinedData;
    } catch (error) {
      _handleError('fetching combined dashboard', error);
      _setLoading(false);
      return {};
    }
  }
}