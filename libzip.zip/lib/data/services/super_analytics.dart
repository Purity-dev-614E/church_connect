
class superAnalytics {

}