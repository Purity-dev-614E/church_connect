import 'dart:convert';
import 'package:http/http.dart' as http;

class AdminAnalyticsService {
  final String baseUrl;
  final Map<String, String> headers;

  AdminAnalyticsService({
    required this.baseUrl,
    required String token,
  }) : headers = {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        };

  // Helper method to handle HTTP responses
  dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return jsonDecode(response.body);
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? 'Failed to complete request');
    }
  }

  // Group Analytics - Admin can only access their own group
  Future<Map<String, dynamic>> getGroupDemographics(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/demographics'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getGroupAttendanceStats(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/attendance'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getGroupGrowthAnalytics(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/growth'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  // Attendance Analytics - Admin can only access their own group's attendance
  Future<Map<String, dynamic>> getGroupAttendanceByPeriod(String groupId, String period) async {
    if (!['week', 'month', 'year'].contains(period)) {
      throw ArgumentError('Period must be one of: week, month, year');
    }
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/attendance/period/$period'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  // Event Analytics - Admin can only access their own group's events
  Future<Map<String, dynamic>> getEventParticipationStats(String eventId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/events/$eventId/participation'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  // Member Analytics - Admin can only access members of their own group
  Future<Map<String, dynamic>> getGroupMemberParticipationStats(
    String groupId, {
    String? startDate,
    String? endDate,
  }) async {
    final queryParams = <String, String>{};
    if (startDate != null) queryParams['start_date'] = startDate;
    if (endDate != null) queryParams['end_date'] = endDate;

    final uri = Uri.parse('$baseUrl/groups/$groupId/members/participation')
        .replace(queryParameters: queryParams);
    
    final response = await http.get(
      uri,
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getGroupMemberActivityStatus(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/members/activity-status'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  // Dashboard Analytics - Admin can only access their own group's dashboard
  Future<Map<String, dynamic>> getGroupDashboardData(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/dashboard'),
      headers: headers,
    );
    return _handleResponse(response);
  }
}