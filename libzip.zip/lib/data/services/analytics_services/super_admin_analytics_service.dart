import 'dart:convert';
import 'package:http/http.dart' as http;

class SuperAdminAnalyticsService {
  final String baseUrl;
  final Map<String, String> headers;

  SuperAdminAnalyticsService({
    required this.baseUrl,
    required String token,
  }) : headers = {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        };

  // Helper method to handle HTTP responses
  dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return jsonDecode(response.body);
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? 'Failed to complete request');
    }
  }

  // Group Analytics
  Future<Map<String, dynamic>> getGroupDemographics(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/demographics'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getGroupAttendanceStats(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/attendance'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getGroupGrowthAnalytics(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups/$groupId/growth'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> compareGroups(List<String> groupIds) async {
    final response = await http.post(
      Uri.parse('$baseUrl/groups/compare'),
      headers: headers,
      body: jsonEncode({'groupIds': groupIds}),
    );
    return _handleResponse(response);
  }

  // Attendance Analytics
  Future<Map<String, dynamic>> getAttendanceByPeriod(String period) async {
    if (!['week', 'month', 'year'].contains(period)) {
      throw ArgumentError('Period must be one of: week, month, year');
    }
    final response = await http.get(
      Uri.parse('$baseUrl/attendance/period/$period'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getOverallAttendanceByPeriod(String period) async {
    if (!['week', 'month', 'year'].contains(period)) {
      throw ArgumentError('Period must be one of: week, month, year');
    }
    final response = await http.get(
      Uri.parse('$baseUrl/attendance/overall/$period'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getUserAttendanceTrends(String userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/attendance/user/$userId'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  // Event Analytics
  Future<Map<String, dynamic>> getEventParticipationStats(String eventId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/events/$eventId/participation'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> compareEventAttendance(List<String> eventIds) async {
    final response = await http.post(
      Uri.parse('$baseUrl/events/compare-attendance'),
      headers: headers,
      body: jsonEncode({'eventIds': eventIds}),
    );
    return _handleResponse(response);
  }

  // Member Analytics
  Future<Map<String, dynamic>> getMemberParticipationStats({
    String? startDate,
    String? endDate,
  }) async {
    final queryParams = <String, String>{};
    if (startDate != null) queryParams['start_date'] = startDate;
    if (endDate != null) queryParams['end_date'] = endDate;

    final uri = Uri.parse('$baseUrl/members/participation')
        .replace(queryParameters: queryParams);
    
    final response = await http.get(
      uri,
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getMemberActivityStatus() async {
    final response = await http.get(
      Uri.parse('$baseUrl/members/activity-status'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  // Dashboard Analytics
  Future<Map<String, dynamic>> getDashboardSummary() async {
    final response = await http.get(
      Uri.parse('$baseUrl/dashboard/summary'),
      headers: headers,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getGroupDashboardData(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/dashboard/group/$groupId'),
      headers: headers,
    );
    return _handleResponse(response);
  }
}